from django.contrib import admin

from adventures.models import (
    AdventureProblem,
    AdventureProblemAttempt,
    AdventureRun,
    AdventureVariant,
    CommandAdventure,
)


@admin.register(CommandAdventure)
class CommandAdventureAdmin(admin.ModelAdmin):
    list_display = ("slug", "title", "module", "is_published", "sort_order")
    list_filter = ("is_published",)
    search_fields = ("title", "slug")


@admin.register(AdventureProblem)
class AdventureProblemAdmin(admin.ModelAdmin):
    list_display = ("slug", "title", "usage", "is_published", "sort_order")
    list_filter = ("is_published",)
    search_fields = ("title", "slug")


@admin.register(AdventureVariant)
class AdventureVariantAdmin(admin.ModelAdmin):
    list_display = ("slug", "adventure_problem", "is_published")
    list_filter = ("is_published",)


@admin.register(AdventureRun)
class AdventureRunAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "command_adventure", "status", "started_at")
    list_filter = ("status",)


@admin.register(AdventureProblemAttempt)
class AdventureProblemAttemptAdmin(admin.ModelAdmin):
    list_display = ("id", "run", "adventure_problem", "status", "final_score")
    list_filter = ("status",)
